# WP-Mapify-Plugin
Mapify plugin for wordpress.Read the README file for more information
