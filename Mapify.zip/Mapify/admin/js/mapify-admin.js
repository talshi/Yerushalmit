(function ($) {

    var wp_mapify_app = angular.module('wp_mapify_app', ['ngRoute']);
    



})(jQuery);
